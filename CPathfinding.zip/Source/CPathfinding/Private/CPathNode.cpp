// Copyright Dominik Trautman. Published in 2022. All Rights Reserved.

#include "CPathNode.h"

CPathAStarNode::CPathAStarNode()
{
}

CPathAStarNode::~CPathAStarNode()
{
}
